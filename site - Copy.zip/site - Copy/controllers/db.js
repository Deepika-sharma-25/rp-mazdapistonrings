var admin = require("firebase-admin");
var serviceAccount = require("../anilenggagraapp-firebase-adminsdk.json");
exports.contactus_sendmail = (req, res,next) => {
if (!admin.apps.length) {
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://anilenggagraapp.firebaseio.com"
});
}

var userDetailsData={
    name:req.body.name,
    email:req.body.email,
    phone:req.body.phone,
    message:req.body.message
};
var db = admin.database();
var ref = db.ref();
ref.push(userDetailsData);
res.redirect('/#contactus');
}