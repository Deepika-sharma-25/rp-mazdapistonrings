var nodemailer = require('nodemailer');
var path = require('path');
var config = require(path.join(__dirname,'../secrets.js'));
exports.contactus_sendmail = (req, res,next) => {
  var transporter = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
        user: 'deepika.sharma.nov1993',
        pass: config.emailPassword
    }
});
var mailOptions = { 
    from: 'deepika.sharma.nov1993@gmail.com',
    to: 'deepika.sharma.nov1993@gmail.com',
    subject: 'New visitor ',
    text: 'Name :'+req.body.name+' Email :'+req.body.email+' Message : '+req.body.message+' MobileNo :'+req.body.mobileno+''
  };
  console.log(mailOptions);
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
  res.redirect('/#contactus');
};

