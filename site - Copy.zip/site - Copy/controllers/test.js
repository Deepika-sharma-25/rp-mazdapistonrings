const nodemailer = require('nodemailer');
// var config = require("secrets");
// var config = require(__dirname+'/secrets');
let aws = require('aws-sdk');

exports.contactus_sendmail = (req, res) => {
    console.log(__dirname);
    // var transporter = nodemailer.createTransport({
    //     service: 'Gmail',
    //     host: 'smtp.gmail.com',
    //     port: 465,
    //     secure: true,
    //     auth: {
    //         user: 'deepika.sharma.nov1993', // Your email id
    //         pass: 'WDTHNO&2593m' // Your password
    //     }
    // });

// create Nodemailer SES transporter
let transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 465,
        secure: true,
        ignoreTLS: false,
        auth: {
                    user: 'deepika.sharma.nov1993', // Your email id
                    pass: 'WDTHNO&2593m' // Your password
                }
});

    var mailOptions = { 
        from: 'deepika.sharma.nov1993@gmail.com',
        to: 'deepika.sharma.nov1993@gmail.com',
        subject: 'New visitor - @anilenginnering',
        text: 'Name :'+req.body.name+' Email :'+req.body.email+' Message : '+req.body.message+' MobileNo :'+req.body.mobileno
      };

      console.log(mailOptions);

      transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
      res.redirect('/#contactus');
};

