const http = require('http');
const express = require('express');
var bodyParser = require('body-parser');
const app = express();

// const adminController = require(__dirname+'/controllers/con-contactus');
const adminController = require(__dirname+'/controllers/db');
app.use(express.json());
app.use(express.static(__dirname + '/images'));
app.use(bodyParser.urlencoded({ extended: true }));

app.post("/contactus", adminController.contactus_sendmail);
// default URL for website
app.get('/', function(req,res){
    // res.sendFile(__dirname+'/express/index.html');
    // res.sendFile(__dirname+'/express/i.html');
    res.sendFile(__dirname+'/express/temp.html');
  });
app.get('*', (req, res) => {
    res.redirect('/')
})
app.set('PORT', 21);
app.listen(app.get('PORT'), '162.210.70.23' , () => {
  console.log("Server is running at " + app.get('PORT'));
});
// app.listen(21);

