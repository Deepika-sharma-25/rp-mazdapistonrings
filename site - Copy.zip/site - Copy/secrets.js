const dotenv = require('dotenv');
dotenv.config();
console.log(process.env.DB_PASSWORD);
module.exports = {
    emailPassword: process.env.DB_PASSWORD
}